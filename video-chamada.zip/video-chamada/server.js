require("dotenv").config();
const express = require("express");
const mysql = require("mysql2");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const SECRET = process.env.JWT_SECRET || "secreto";

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "", // sua senha aqui
  database: "videochamada"
});

db.connect(err => {
  if (err) throw err;
  console.log("MySQL conectado.");
});

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// Middleware para verificar JWT (usado em rotas REST)
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.sendStatus(401);
  const token = authHeader.split(" ")[1];
  jwt.verify(token, SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

// Registro
app.post("/api/register", (req, res) => {
  const { email, password } = req.body;
  bcrypt.hash(password, 10, (err, hash) => {
    if (err) return res.status(500).json({ message: "Erro no servidor" });
    const sql = "INSERT INTO users (email, password) VALUES (?, ?)";
    db.query(sql, [email, hash], (err) => {
      if (err) return res.status(400).json({ message: "Email já cadastrado" });
      res.status(201).json({ message: "Usuário criado" });
    });
  });
});

// Login
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  const sql = "SELECT * FROM users WHERE email = ?";
  db.query(sql, [email], (err, results) => {
    if (err || results.length === 0)
      return res.status(404).json({ message: "Usuário não encontrado" });
    const user = results[0];
    bcrypt.compare(password, user.password, (err, match) => {
      if (!match) return res.status(401).json({ message: "Senha incorreta" });
      const token = jwt.sign({ id: user.id, email: user.email }, SECRET, { expiresIn: "1h" });
      res.json({ token });
    });
  });
});

// Criar chamada
app.post("/api/create-call", authMiddleware, (req, res) => {
  const roomId = Math.random().toString(36).substring(2, 10);
  const userId = req.user.id;
  const sql = "INSERT INTO calls (room_id, created_by) VALUES (?, ?)";
  db.query(sql, [roomId, userId], (err) => {
    if (err) return res.status(500).json({ message: "Erro ao criar chamada" });
    res.json({ room_id: roomId });
  });
});

// Encerrar chamada
app.post("/api/end-call", authMiddleware, (req, res) => {
  const { room_id } = req.body;
  const sql = "UPDATE calls SET ended_at = NOW() WHERE room_id = ?";
  db.query(sql, [room_id], (err) => {
    if (err) return res.status(500).json({ message: "Erro ao encerrar chamada" });
    res.json({ message: "Chamada encerrada" });
  });
});

// Servir página da chamada SEM autenticação no backend (autenticação via frontend)
app.get("/call/:roomId", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "call.html"));
});

// Middleware de autenticação para socket.io
io.use((socket, next) => {
  const token = socket.handshake.auth.token;
  if (!token) return next(new Error("Autenticação necessária"));

  jwt.verify(token, SECRET, (err, user) => {
    if (err) return next(new Error("Token inválido"));
    socket.user = user;
    next();
  });
});

// Eventos socket.io
io.on("connection", (socket) => {
  socket.on("join-room", (roomId) => {
    socket.join(roomId);
    socket.to(roomId).emit("user-connected", socket.id);

    socket.on("signal", (data) => {
      io.to(data.target).emit("signal", {
        caller: socket.id,
        signal: data.signal
      });
    });

    socket.on("disconnect", () => {
      socket.to(roomId).emit("user-disconnected", socket.id);
    });
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
