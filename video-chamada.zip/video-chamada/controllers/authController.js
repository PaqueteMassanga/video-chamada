const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const SECRET = process.env.JWT_SECRET || "secreto";
exports.register = (req, res) => {
  const { email, password } = req.body;
  bcrypt.hash(password, 10, (err, hash) => {
    if (err) return res.status(500).json({ message: "Erro no servidor" });
    User.create(email, hash, (err) => {
      if (err) return res.status(400).json({ message: "Email já cadastrado" });
      res.status(201).json({ message: "Usuário criado" });
    });
  });
};
exports.login = (req, res) => {
  const { email, password } = req.body;
  User.findByEmail(email, (err, results) => {
    if (err || results.length === 0) return res.status(404).json({ message: "Usuário não encontrado" });
    const user = results[0];
    bcrypt.compare(password, user.password, (err, match) => {
      if (!match) return res.status(401).json({ message: "Senha incorreta" });
      const token = jwt.sign({ id: user.id, email: user.email }, SECRET, { expiresIn: "1h" });
      res.json({ token });
    });
  });
};
