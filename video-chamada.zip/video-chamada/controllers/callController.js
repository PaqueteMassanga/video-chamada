const Call = require("../models/Call");
exports.createCall = (req, res) => {
  const roomId = Math.random().toString(36).substring(2, 10);
  const userId = req.user.id;
  Call.create(roomId, userId, (err) => {
    if (err) return res.status(500).json({ message: "Erro ao criar chamada" });
    res.json({ room_id: roomId });
  });
};
exports.endCall = (req, res) => {
  const { room_id } = req.body;
  Call.end(room_id, (err) => {
    if (err) return res.status(500).json({ message: "Erro ao encerrar chamada" });
    res.json({ message: "Chamada encerrada" });
  });
};