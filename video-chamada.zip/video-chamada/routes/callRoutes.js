const express = require("express");
const router = express.Router();
const callController = require("../controllers/callController");
const auth = require("../middlewares/authMiddleware");
router.post("/create-call", auth, callController.createCall);
router.post("/end-call", auth, callController.endCall);
module.exports = router;