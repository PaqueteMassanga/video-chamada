const db = require("../config/db");
const User = {
  create: (email, hash, callback) => {
    const sql = "INSERT INTO users (email, password) VALUES (?, ?)";
    db.query(sql, [email, hash], callback);
  },
  findByEmail: (email, callback) => {
    const sql = "SELECT * FROM users WHERE email = ?";
    db.query(sql, [email], callback);
  }
};
module.exports = User;