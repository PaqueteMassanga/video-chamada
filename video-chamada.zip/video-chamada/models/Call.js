const db = require("../config/db");
const Call = {
  create: (roomId, userId, callback) => {
    const sql = "INSERT INTO calls (room_id, created_by) VALUES (?, ?)";
    db.query(sql, [roomId, userId], callback);
  },
  end: (roomId, callback) => {
    const sql = "UPDATE calls SET ended_at = NOW() WHERE room_id = ?";
    db.query(sql, [roomId], callback);
  }
};
module.exports = Call;