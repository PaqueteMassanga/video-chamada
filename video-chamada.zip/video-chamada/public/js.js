// === Utils ===
  const apiBase = ''; // mesma origem do backend
  let socket = null;
  let peerConnection = null;
  let localStream = null;
  let remoteSocketId = null;
  let currentRoomId = null;

  // === Seletor de telas ===
  const sections = {
    login: document.getElementById('login-section'),
    register: document.getElementById('register-section'),
    room: document.getElementById('room-section'),
    call: document.getElementById('call-section')
  };

  function showSection(name) {
    Object.values(sections).forEach(s => s.classList.add('hidden'));
    sections[name].classList.remove('hidden');
  }

  // === Eventos para mudar telas ===
  document.getElementById('btn-show-register').onclick = () => {
    showSection('register');
    clearErrors();
  };
  document.getElementById('btn-show-login').onclick = () => {
    showSection('login');
    clearErrors();
  };

  // === Clear errors ===
  function clearErrors() {
    ['login-error', 'register-error', 'room-error'].forEach(id => {
      const el = document.getElementById(id);
      if(el) el.textContent = '';
    });
  }

  // === LOGIN ===
  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors();

    const email = e.target['login-email'].value;
    const password = e.target['login-password'].value;

    try {
      const res = await fetch(apiBase + '/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        document.getElementById('login-error').textContent = data.message || 'Erro ao fazer login.';
        return;
      }

      localStorage.setItem('token', data.token);
      showSection('room');
    } catch {
      document.getElementById('login-error').textContent = 'Erro de conexão.';
    }
  });

  // === REGISTER ===
  document.getElementById('register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors();

    const email = e.target['register-email'].value;
    const password = e.target['register-password'].value;

    try {
      const res = await fetch(apiBase + '/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        document.getElementById('register-error').textContent = data.message || 'Erro ao registrar.';
        return;
      }
      alert('Usuário registrado com sucesso! Faça login.');
      showSection('login');
    } catch {
      document.getElementById('register-error').textContent = 'Erro de conexão.';
    }
  });

  // === LOGOUT ===
  document.getElementById('btn-logout').addEventListener('click', () => {
    localStorage.removeItem('token');
    if(socket) socket.disconnect();
    showSection('login');
  });

  // === CREATE ROOM ===
  document.getElementById('btn-create-room').addEventListener('click', async () => {
    clearErrors();
    const token = localStorage.getItem('token');
    if (!token) return showSection('login');

    try {
      const res = await fetch(apiBase + '/api/create-call', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (!res.ok) {
        document.getElementById('room-error').textContent = data.message || 'Erro ao criar sala.';
        return;
      }
      joinRoom(data.room_id);
    } catch {
      document.getElementById('room-error').textContent = 'Erro de conexão.';
    }
  });

  // === JOIN ROOM ===
  document.getElementById('join-room-form').addEventListener('submit', (e) => {
    e.preventDefault();
    clearErrors();
    const roomId = e.target['join-room-id'].value.trim();
    if (!roomId) return;

    joinRoom(roomId);
  });

  // === Join Room & Setup WebRTC & Socket.IO ===
  async function joinRoom(roomId) {
    currentRoomId = roomId;
    showSection('call');
    document.getElementById('current-room-id').textContent = roomId;

    const token = localStorage.getItem('token');
    if (!token) {
      alert('Você precisa estar autenticado.');
      showSection('login');
      return;
    }

    // Setup Socket.IO
    if(socket) socket.disconnect();
    socket = io({ auth: { token } });

    socket.on('connect_error', (err) => {
      alert('Erro na conexão WebSocket: ' + err.message);
      showSection('room');
    });

    socket.on('user-connected', async (id) => {
      remoteSocketId = id;
      try {
        const offer = await peerConnection.createOffer();
        await peerConnection.setLocalDescription(offer);

        socket.emit('signal', {
          target: id,
          signal: { sdp: offer }
        });
      } catch (err) {
        console.error('Erro criando offer:', err);
      }
    });

    socket.on('signal', async ({ caller, signal }) => {
      remoteSocketId = caller;
      try {
        if (signal.sdp) {
          await peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp));

          if (signal.sdp.type === 'offer') {
            const answer = await peerConnection.createAnswer();
            await peerConnection.setLocalDescription(answer);

            socket.emit('signal', {
              target: caller,
              signal: { sdp: answer }
            });
          }
        } else if (signal.candidate) {
          await peerConnection.addIceCandidate(new RTCIceCandidate(signal.candidate));
        }
      } catch (err) {
        console.error('Erro em sinalização:', err);
      }
    });

    socket.on('user-disconnected', () => {
      document.getElementById('remoteVideo').srcObject = null;
      remoteSocketId = null;
    });

    socket.emit('join-room', roomId);

    // Setup WebRTC
    peerConnection = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
    });

    peerConnection.ontrack = (event) => {
      document.getElementById('remoteVideo').srcObject = event.streams[0];
    };

    peerConnection.onicecandidate = (event) => {
      if (event.candidate && remoteSocketId) {
        socket.emit('signal', {
          target: remoteSocketId,
          signal: { candidate: event.candidate }
        });
      }
    };

    try {
      localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      document.getElementById('localVideo').srcObject = localStream;
      localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));
    } catch (err) {
      alert('Erro ao acessar a câmera/microfone.');
      showSection('room');
      return;
    }
  }

  // === END CALL ===
  document.getElementById('btn-end-call').addEventListener('click', () => {
    if(peerConnection) {
      peerConnection.close();
      peerConnection = null;
    }
    if(socket) {
      socket.emit('leave-room', currentRoomId);
      socket.disconnect();
      socket = null;
    }
    if(localStream) {
      localStream.getTracks().forEach(track => track.stop());
      localStream = null;
    }
    document.getElementById('localVideo').srcObject = null;
    document.getElementById('remoteVideo').srcObject = null;
    currentRoomId = null;
    showSection('room');
  });

  // Se já estiver logado, vai direto para sala
  if (localStorage.getItem('token')) {
    showSection('room');
  } else {
    showSection('login');
  }


 // js.js


const localVideo = document.getElementById('localVideo');
const remoteVideo = document.getElementById('remoteVideo');

const btnToggleMic = document.getElementById('btn-toggle-mic');
const btnToggleCamera = document.getElementById('btn-toggle-camera');
const btnShareScreen = document.getElementById('btn-share-screen');

const iconMicOn = document.getElementById('icon-mic-on');
const iconMicOff = document.getElementById('icon-mic-off');
const iconCameraOn = document.getElementById('icon-camera-on');
const iconCameraOff = document.getElementById('icon-camera-off');

async function startLocalStream() {
  try {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    localVideo.srcObject = localStream;
    updateMicIcon(true);
    updateCameraIcon(true);
  } catch (error) {
    console.error('Erro ao acessar mídia:', error);
  }
}

function toggleMic() {
  const track = localStream?.getAudioTracks()[0];
  if (!track) return;
  track.enabled = !track.enabled;
  updateMicIcon(track.enabled);
}

function toggleCamera() {
  const track = localStream?.getVideoTracks()[0];
  if (!track) return;
  track.enabled = !track.enabled;
  updateCameraIcon(track.enabled);
}

function updateMicIcon(isOn) {
  iconMicOn.classList.toggle('hidden', !isOn);
  iconMicOff.classList.toggle('hidden', isOn);
}

function updateCameraIcon(isOn) {
  iconCameraOn.classList.toggle('hidden', !isOn);
  iconCameraOff.classList.toggle('hidden', isOn);
}

async function shareScreen() {
  try {
    const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
    const videoTrack = screenStream.getVideoTracks()[0];

    // Substitui vídeo local temporariamente
    localVideo.srcObject = screenStream;

    videoTrack.onended = () => {
      // Voltar para câmera ao encerrar o compartilhamento
      if (localStream) {
        localVideo.srcObject = localStream;
      }
    };
  } catch (error) {
    console.error('Erro ao compartilhar tela:', error);
  }
}

// Eventos
btnToggleMic.addEventListener('click', toggleMic);
btnToggleCamera.addEventListener('click', toggleCamera);
btnShareScreen.addEventListener('click', shareScreen);

startLocalStream();
